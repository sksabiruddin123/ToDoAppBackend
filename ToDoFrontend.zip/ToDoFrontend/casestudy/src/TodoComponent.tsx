import { Button, Container, Form } from "react-bootstrap";
import { useHistory, useParams } from "react-router-dom";
import { createTodo, getTodo, updateTodo } from "./services/Todo";
import { useState, useEffect, FormEvent } from "react";


interface RouteParam{
    id:string
}

type todo={
    id:number;
    title:string,
    description:string,
    completed:boolean
}

const TodoComponent=()=>{

    let [title,setTitle] = useState<string>("");
    let [description,setDescription] = useState<string>("");
    let [completed ,setCompleted]  =useState<boolean>(false);

    let {id} = useParams<RouteParam>();
    let navigator=useHistory();

    useEffect(()=> {
        if(id){
         getTodoById(Number(id))
        }
      },[id])

    function getTodoById(id:number){

        getTodo(id)
        .then((response) => {
        console.log(response.data);
        setTitle(response.data.title);
        setDescription(response.data.description);
        setCompleted(response.data.completed)
        }).catch((error) => console.log(error))

    }

     function saveTodo(e:FormEvent){
        e.preventDefault();
        let todo ={title,description,completed}

        if (id) {
            updateTodo(Number(id),todo)
            .then((response) =>{
                console.log(response.data);
                navigator.push("/")
        }).catch((error)=>console.log(error));
        }else {
            createTodo(todo)
            .then((response) => {
                console.log(response.data);
                navigator.push("/");
            }).catch((error) => console.log(error));
        }
      

     }

    return(<>
          
      <Container className="todo-form-title">
          
          <h2>{id ? "Update Todo" : "Create Todo" }</h2>

        <Form onSubmit={(e)=>saveTodo(e)} >

            <Form.Group className="form-group" controlId="title">
                <Form.Label>Todo Title</Form.Label>
                <Form.Control type="text"
                              placeholder="Enter todo title"
                              value={title}
                              onChange={(e) => setTitle(e.target.value)}
                />
            </Form.Group>

            <Form.Group className="form-group" controlId="description">
                <Form.Label>Todo Description</Form.Label>
                <Form.Control type="text"
                              placeholder="Enter description"
                              value={description}
                              onChange={(e) => setDescription(e.target.value)}
                />
            </Form.Group>

            <Form.Group className="form-group" controlId="completed">
                <Form.Label>Completed?</Form.Label>
                <Form.Select  
                              value={completed.toString()}
                              onChange={(e) => 
                                setCompleted(e.target.value === "true")}
                             >
                             <option value="false" >No</option>
                             <option value="true" >Yes</option>
                </Form.Select>
            </Form.Group>

            <Button type="submit" className="btn-submit btn-primary">
                    {id ? "Update" : "Create"}
                </Button>

        </Form>
      </Container>

        </>)

}

export default TodoComponent;