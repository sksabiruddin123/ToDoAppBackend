import { useEffect, useState } from "react";
import { completeTodo, deleteTodo, incompleteTodo, listTodos, updateTodo } from "./services/Todo";
import { Button, Container, Table } from "react-bootstrap";
import { useHistory } from "react-router-dom";

type todo={
    id:number;
    title:string,
    description:string,
    completed:boolean
}

const ListOfTodo =() => {
 
    let[todos,setTodos] = useState<todo[]>([]);
    

    function getTodos(){
        listTodos().then((response) => {
            console.log(response.data)
            setTodos(response.data)
        }).catch((error) => console.log(error))
    }

    function deleteTask(id: number) {
        deleteTodo(id).then((response) => {
            console.log(response.data)
            getTodos()
        }).catch((error) => console.log(error))
    }

    function completeTask(id:number){
        completeTodo(id).then((response) => {
            console.log(response.data)
           getTodos()
        }).catch((error) => console.log(error))

    }

    function incompleteTask(id:number){
        incompleteTodo(id).then((response) => {
            console.log(response.data)
           getTodos()
        }).catch((error) => console.log(error))

    }

    useEffect(()=>getTodos(),[]);

    let navigator = useHistory()

    function editTodo(id: number) {
       navigator.push(`update-todo/${id}`)
    }

    const handleCreateTodo = () => {
        navigator.push("/create-todo");
    };


    return(<>
 
      <header className="app-header">
        <h1>Todo Management Application</h1>
      </header>

      <Container className="main-container">

      <div className="todo-header" >
                <Button onClick={handleCreateTodo} 
                        variant="primary"
                        className="btn-create-todo">
                            Create Todo
                </Button>

      </div>

      <h2 className="todo-list-title">List of Todos</h2>


      <Table striped bordered hover >
      <thead>
        <tr>
          <th>Id</th>
          <th>Todo Title</th>
          <th>Todo Description</th>
          <th>Todo Completed?</th>
          <th className="action-column">Action</th>
        </tr>
      </thead>
      <tbody>

        {
            todos.map((todo) =>(
        <tr key={todo.id}>
          <td>{todo.id}</td>
          <td>{todo.title}</td>
          <td>{todo.description}</td>
          <td>{todo.completed ? "Yes" : "No"}</td>

          <td className="action-column">
          <div className="action-buttons">
          <Button onClick={() => editTodo(todo.id)} variant="warning">
                    Update
              </Button>
       
          <Button onClick={() => completeTask(todo.id)} variant="success">
                  Complete
              </Button>
       
          <Button onClick={() => incompleteTask(todo.id)} variant="secondary">
                Incomplete
             </Button>
        
          <Button onClick={() => deleteTask(todo.id)} variant="danger">
                Delete
            </Button>
        </div>
        </td>
        </tr>
           ))}

      </tbody>
        
    </Table>
    
    </Container>

    </>)
}

export default ListOfTodo;