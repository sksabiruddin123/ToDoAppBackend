import { BrowserRouter, Route, Switch } from "react-router-dom";
import ListOfTodo from "./ListOfTodo";
import 'bootstrap/dist/css/bootstrap.min.css';
import TodoComponent from "./TodoComponent";
import './style.css';  // Import the new CSS file


function App(){
    return(<>
   
   <BrowserRouter>
   <Switch>
    <Route exact path="/" component={ListOfTodo} ></Route>
    <Route exact path="/create-todo" component={TodoComponent} />
    <Route exact path="/update-todo/:id" component={TodoComponent} ></Route>
   </Switch>
   </BrowserRouter>

    </>)
}


export default App;